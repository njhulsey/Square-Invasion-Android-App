package com.nickhulsey.MenuObjects;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.nickhulsey.Handlers.MenuHandler;

/**
 * Created by nickhulsey on 11/30/14.
 */
public class PlayButton {
    private MenuHandler MH;
    private Paint p;
    public float x,y,w,h;


    public PlayButton(float x, float y, float w, float h, MenuHandler MH){
        this.MH = MH;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;

        p = new Paint();
        p.setStyle(Paint.Style.FILL);
        p.setTextSize(90f);
    }

    public void tick(){
        if(MH.Mpressed){
            if(MH.Mx > x && MH.Mx < x + w && MH.My > y && MH.My < y + h){
                MH.game.GH.init = false;
                MH.game.GH.start();
                MH.game.State = "Game";
            }else if(MH.Mx1 > x && MH.Mx1 < x + w && MH.My1 > y && MH.My1 < y + h){
                MH.game.GH.init = false;
                MH.game.GH.start();
                MH.game.State = "Game";
            }
        }

    }

    public void draw(Canvas canvas){
        p.setARGB(150,220,220,220);
        canvas.drawRect(x,y,x + w, y + h,p);

        p.setColor(Color.WHITE);
        canvas.drawText("Play",x + w / 8,y + h / 2,p);

        canvas.drawText("HScore: " + MH.game.GH.score.HighScore,50,200,p);
        canvas.drawText("LScore: " + MH.game.GH.score.LastScore,50,500,p);

    }




}
