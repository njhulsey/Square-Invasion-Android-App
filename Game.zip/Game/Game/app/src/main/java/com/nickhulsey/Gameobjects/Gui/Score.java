package com.nickhulsey.Gameobjects.Gui;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.nickhulsey.Handlers.GameHandler;

/**
 * Created by nickhulsey on 11/20/14.
 */
public class Score {
    private GameHandler OH;
    public int Score = 0;
    public int LastScore = 0;
    public int HighScore = 0;

    float x;
    float y;

    public Score(float x, float y, int Score, GameHandler OH){
        this.OH = OH;
        this.x = x;
        this.y = y;
        this.Score = Score;
    }

    public void tick(){

    }

    public void draw(Canvas canvas){
        Paint p = new Paint();
        p.setTextSize(80f);
        p.setColor(Color.LTGRAY);

        canvas.drawText("Pixels: " + Score, x, y,p);
    }

}
