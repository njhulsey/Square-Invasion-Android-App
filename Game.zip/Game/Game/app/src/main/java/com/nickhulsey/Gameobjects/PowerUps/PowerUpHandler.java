package com.nickhulsey.Gameobjects.PowerUps;

import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.game.ObjectID;

import java.util.Random;

/**
 * Created by nickhulsey on 11/24/14.
 */
public class PowerUpHandler {
    private GameHandler GH;

    private int count = 0;
    private int spawnRate = 320;
    private int guess;
    private Random r;

    //power up width
    private float Pw;

    // TODO: Add new colors here
    private int[] tripleC = new int[]{255,60,60,110};
    private int[] doubleC = new int[]{255,110,110,0};
    private int[] rateC = new int[]{255,100,0,100};
    private int[] largeC = new int[]{255,110,110,110};
    private int[] speedC = new int[]{150,210,62,0};
    private int[] healthC;


    public PowerUpHandler(GameHandler GH){
        this.GH = GH;
        Pw = GH.player.w / 1.6f;

        r = new Random();
        healthC = GH.player.color;
    }

    public void tick(){
        count ++;//++;
        if(count >= spawnRate - (GH.spawner.difficulty * 13)) {
            guess = r.nextInt(15);
            if (guess == 1) {
                guess = r.nextInt((int) GH.SCREEN_WIDTH - (int)Pw);
                GH.Objects.add(new PowerUp((int) guess, 0 - Pw, Pw, Pw, "triple", tripleC, ObjectID.PowerUp, GH));
            }else if(guess == 2){
                guess = r.nextInt((int) GH.SCREEN_WIDTH - (int)Pw);
                GH.Objects.add(new PowerUp((int) guess, 0 - Pw, Pw, Pw, "double", doubleC, ObjectID.PowerUp, GH));
            }else if(guess == 3){
                guess = r.nextInt((int) GH.SCREEN_WIDTH - (int)Pw);
                GH.Objects.add(new PowerUp((int) guess, 0 - Pw, Pw, Pw, "rate", rateC, ObjectID.PowerUp, GH));
            }else if(guess == 4){
                guess = r.nextInt((int) GH.SCREEN_WIDTH - (int)Pw);
                GH.Objects.add(new PowerUp((int) guess, 0 - Pw, Pw, Pw, "health", healthC, ObjectID.PowerUp, GH));
            }else if(guess == 5){
                guess = r.nextInt((int) GH.SCREEN_WIDTH - (int)Pw);
                GH.Objects.add(new PowerUp((int) guess, 0 - Pw, Pw, Pw, "large", largeC, ObjectID.PowerUp, GH));
            }else if(guess == 6){
                guess = r.nextInt((int) GH.SCREEN_WIDTH - (int)Pw);
                GH.Objects.add(new PowerUp((int) guess, 0 - Pw, Pw, Pw, "speed", speedC, ObjectID.PowerUp, GH));
            }

            count = 0; guess = 0;
        }
    }

    public int[] getColor(String power){
        if(power == "triple"){return tripleC;}
        if(power == "double"){return doubleC;}
        if(power == "rate"){return rateC;}
        if(power == "large"){return largeC;}
        if(power == "speed"){return speedC;}
        if(power == "health"){return healthC;}

        return null;
    }


}
