package com.nickhulsey.game;

/**
 * Created by nickhulsey on 11/18/14.
 */
public enum ObjectID {
    Enemy(),EnemyBullet(),PlayerBullet(),Player(),Particle(),PowerUp(), PopupText(),  Button();
}
