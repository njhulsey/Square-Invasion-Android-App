package com.nickhulsey.Gameobjects.Objects;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.nickhulsey.Abstracts.Entity;
import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.Particles.BSparkleEmitter;
import com.nickhulsey.Particles.ParticleEmitter;
import com.nickhulsey.game.ObjectID;

/**
 * Created by nickhulsey on 11/15/14.
 */
public class Bullet extends Entity {
    public float speed;
    private ParticleEmitter PE;

    public Bullet(float x, float y, float w, float h, int damage, float speed, int[] color, ObjectID id, GameHandler GH) {
        super(x, y, w, h, id, GH);
        this.damage = damage;
        this.color = color;
        this.speed = speed;
        PE = new BSparkleEmitter(2,this);

        p.setARGB(this.color[0],this.color[1],this.color[2],this.color[3]);

    }

    public void tick() {
        setRect();
        if(y > 0 - h || y < OH.SCREEN_HEIGHT + h) {
            y-= speed;
        }else{OH.Objects.remove(this);}
        PE.tick();
    }
    public void draw(Canvas c) {
        PE.draw(c);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(x,y,x+w,y+h,p);
    }



}
