package com.nickhulsey.Handlers;

import android.graphics.Canvas;

import com.nickhulsey.Abstracts.Handler;
import com.nickhulsey.PauseObjects.MenuButton;
import com.nickhulsey.PauseObjects.PauseButton;
import com.nickhulsey.PauseObjects.ResetButton;
import com.nickhulsey.game.Game;

/**
 * Created by nickhulsey on 11/21/14.
 */
public class PauseHandler extends Handler{

    public PauseButton PB;
    public ResetButton RB;
    public MenuButton  MB;


    public PauseHandler(Game game){
        super(game);
    }

    public void start(){
        if(!init){
            PB = new PauseButton(SCREEN_WIDTH / 4,SCREEN_HEIGHT / 2 - 200,(SCREEN_WIDTH/4) * 2, 200f,this);
            RB = new ResetButton(SCREEN_WIDTH / 4,SCREEN_HEIGHT / 2 + 100,(SCREEN_WIDTH/4) * 2, 200f,this);
            MB = new MenuButton(SCREEN_WIDTH / 4,SCREEN_HEIGHT / 2 + 400,(SCREEN_WIDTH/4) * 2, 200f,this);
        }
    }

    public void tick(){
        game.GH.spaceEmitter.tick();
        PB.tick();
        RB.tick();
        MB.tick();
    }

    public void draw(Canvas canvas){
        game.GH.spaceEmitter.draw(canvas);

        RB.draw(canvas);
        PB.draw(canvas);
        MB.draw(canvas);
    }

}
