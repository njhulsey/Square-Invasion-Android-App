package com.nickhulsey.Abstracts;

import android.graphics.Canvas;

import com.nickhulsey.game.Game;

/**
 * Created by nickhulsey on 11/30/14.
 */
public abstract class Handler {
    public Game game;
    public boolean init = false;
    public float SCREEN_WIDTH = 0;
    public float SCREEN_HEIGHT = 0;

    //mouse stuff
    public float Mx,My,Mx1,My1 = 0;
    public boolean Mpressed = false;


    public Handler(Game game){
        this.game = game;
    }


    public abstract void tick();
    public abstract void draw(Canvas canvas);
    public abstract void start();

    public void Mouse(float Mx, float My, float Mx1, float My1){
        this.Mx = Mx;
        this.My = My;
        this.Mx1 = Mx1;
        this.My1 = My1;
    }

}
