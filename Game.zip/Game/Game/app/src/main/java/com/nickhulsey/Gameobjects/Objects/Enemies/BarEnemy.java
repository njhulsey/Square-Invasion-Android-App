package com.nickhulsey.Gameobjects.Objects.Enemies;

import android.graphics.Canvas;
import android.graphics.Color;
import android.widget.EditText;

import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.game.ObjectID;

/**
 * Created by nickhulsey on 12/6/14.
 */
public class BarEnemy extends Enemy{

    public BarEnemy(float x, float y, float w, float h, float speed,  float difficulty, ObjectID id, GameHandler OH) {
        super(x, y, w, h, difficulty, id, OH);
        this.speed = speed;
        color = new int[]{255,110,0,0};

        health = 1;
    }

    public void tick() {
        setRect();
        if (y < OH.SCREEN_HEIGHT + h) {
            y += speed;
        } else {
            OH.Objects.remove(this);
        }

        for (int i = 0; i < OH.Objects.size(); i++) {
            if (OH.Objects.get(i).id == ObjectID.PlayerBullet) {
                if (r.intersect(OH.Objects.get(i).r) && OH.Objects.get(i) != null) {
                    OH.Objects.remove(OH.Objects.get(i));
                }
            }
        }

        if (health <= 0) {
            die();
        }

    }

    public void draw(Canvas c) {
        p.setARGB(color[0],color[1],color[2],color[3]);
        c.drawRect(x, y, x + w, y + h, p);
    }
}
