package com.nickhulsey.PauseObjects;

import android.graphics.Canvas;
import android.graphics.Color;

import com.nickhulsey.Abstracts.Button;
import com.nickhulsey.Abstracts.Handler;

/**
 * Created by nickhulsey on 11/30/14.
 */
public class MenuButton extends Button {

    public MenuButton(float x, float y, float w, float h, Handler H) {
        super(x, y, w, h, H);
    }

    public void tick(){
        if(H.Mpressed){
            if(H.Mx > x && H.Mx < x + w && H.My > y && H.My < y + h){
                H.game.State = "Menu";
            }else if(H.Mx1 > x && H.Mx1 < x + w && H.My1 > y && H.My1 < y + h){
                H.game.State = "Menu";
            }
        }

    }

    public void draw(Canvas canvas){
        p.setARGB(150,220,220,220);
        canvas.drawRect(x,y,x + w, y + h,p);

        p.setColor(Color.WHITE);
        canvas.drawText("Menu",x + w / 8,y + h / 2,p);
    }

}
