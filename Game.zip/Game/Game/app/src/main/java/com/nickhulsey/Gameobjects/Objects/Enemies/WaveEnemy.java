package com.nickhulsey.Gameobjects.Objects.Enemies;

import android.graphics.Canvas;
import android.graphics.Color;

import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.game.ObjectID;

/**
 * Created by nickhulsey on 12/9/14.
 */
public class WaveEnemy extends Enemy{
    private boolean left = true;
    private int count = 0;

    public WaveEnemy(float x, float y, float w, float h, float difficulty, ObjectID id, GameHandler OH) {
        super(x, y, w, h, difficulty, id, OH);
        color = new int[]{255,100,0,100};

    }

    public void tick() {
        setRect();

        //left-right thing
        if(left){
            count++;
            if (count >= w / 1) {count = 0;left = false;}
            if(x > 0) {x -= 3;}else {left = false;}
        }else if(!left){
            count++;
            if (x + w < OH.SCREEN_WIDTH) {x += 3;}else{left = true;}
            if (count >= w / 1) {count = 0;left = true;}
        }

        //check if move possible
        if (y < OH.SCREEN_HEIGHT + h) {
            y += speed;
        } else {
            OH.Objects.remove(this);
        }

        for (int i = 0; i < OH.Objects.size(); i++) {
            if (OH.Objects.get(i).id == ObjectID.PlayerBullet) {
                if (r.intersect(OH.Objects.get(i).r) && OH.Objects.get(i) != null) {
                    health -= OH.Objects.get(i).damage;
                    OH.Objects.remove(OH.Objects.get(i));
                }
            }
        }

        if (health <= 0) {die();}

    }

    public void draw(Canvas c) {
        p.setARGB(color[0],color[1],color[2],color[3]);
        c.drawRect(x, y, x + w, y + h, p);

        p.setColor(Color.LTGRAY);
        c.drawText(health+"", x + (w/4), y + (h/1.65f) + 10, p);
    }

}
