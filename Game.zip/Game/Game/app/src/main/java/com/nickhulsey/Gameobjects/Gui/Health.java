package com.nickhulsey.Gameobjects.Gui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.nickhulsey.Handlers.GameHandler;

/**
 * Created by nickhulsey on 11/22/14.
 */
public class Health {
    private GameHandler GH;

    public float x,y,w,h;
    public int maxLives = 3;
    public int lives = maxLives;
    private Paint p;


    public Health(float x, float y, float w, float h, GameHandler GH){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.GH = GH;

        p = new Paint();
        p.setStyle(Paint.Style.FILL);
    }

    public void tick(){
        if(lives < 0){
            GH.game.saveGame();
            GH.game.loadGame();
            GH.game.State = "Over";
        }

        if(lives > maxLives){lives = maxLives;}
    }

    public void draw(Canvas canvas){
        p.setARGB(130,GH.player.color[1], GH.player.color[2], GH.player.color[3]);

        for(int i = 0; i < lives; i++) {
            canvas.drawRect(x + (i * 150), y, x + w + (i * 150), y + h, p);
        }
    }


}
