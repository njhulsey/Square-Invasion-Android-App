package com.nickhulsey.Handlers;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.nickhulsey.Abstracts.Handler;
import com.nickhulsey.PauseObjects.MenuButton;
import com.nickhulsey.PauseObjects.ResetButton;
import com.nickhulsey.game.Game;

/**
 * Created by nickhulsey on 12/9/14.
 */
public class OverHandler extends Handler {
    private Paint p;

    public ResetButton RB;
    public MenuButton MB;

    public OverHandler(Game game) {
        super(game);

        p = new Paint();
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE);

    }

    public void start() {
        if(!init){
            RB = new ResetButton(SCREEN_WIDTH / 4,SCREEN_HEIGHT / 3,(SCREEN_WIDTH/4) * 2, 200f,this);
            MB = new MenuButton(SCREEN_WIDTH / 4, SCREEN_HEIGHT / 2 + 100,(SCREEN_WIDTH/4) * 2, 200f,this);

        }
    }

    public void tick() {
        RB.tick();
        MB.tick();
    }

    public void draw(Canvas canvas) {
        RB.draw(canvas);
        MB.draw(canvas);

        p.setTextSize(200f);
        canvas.drawText("Game Over!",20,300,p);

        p.setTextSize(100f);
        canvas.drawText("Your score was: " + game.GH.score.LastScore, 20, 500, p);

    }

}
