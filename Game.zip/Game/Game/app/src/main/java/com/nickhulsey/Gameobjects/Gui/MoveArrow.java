package com.nickhulsey.Gameobjects.Gui;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.nickhulsey.Abstracts.Entity;
import com.nickhulsey.Gameobjects.Objects.Bullet;
import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.Particles.PopUpText;
import com.nickhulsey.game.ObjectID;

/**
 * Created by nickhulsey on 11/15/14.
 */
public class MoveArrow extends Entity {

    private String direction;
    private int C = 0;

    public int ROF = 16; //rate of fire
    public int Bdamage = 1; // bullet damage
    public float BSizeW = 55f;
    public float BSizeH = 55f;
    public float BSpeed = 17f;

    public int[] BColor = OH.player.color;


    public MoveArrow(float x, float y, float w, float h, String direction, ObjectID id, GameHandler OH) {
        super(x, y, w, h, id, OH);
        this.direction = direction;
        p = new Paint();
        p.setStyle(Paint.Style.FILL);
        p.setTextSize(150f);
    }

    public void tick() {
        if(OH.Mpressed){
            if(OH.Mx > x && OH.Mx < x + w && OH.My > y && OH.My < y + h){
                if(direction == "left"){OH.player.moveLeft();}
                if(direction == "right"){OH.player.moveRight();}
                if(direction == "pause"){OH.game.State = "Pause";}
                if(direction == "fire" && C >= ROF){//16
                    fire();
                    C = 0;
                }

            }else if(OH.Mx1 > x && OH.Mx1 < x + w && OH.My1 > y && OH.My1 < y + h){
                if(direction == "left"){OH.player.moveLeft();}
                if(direction == "right"){OH.player.moveRight();}
                if(direction == "pause"){OH.game.State = "Pause";}
                if(direction == "fire" && C >= ROF){//16
                    fire();
                    C = 0;
                }
            }
        }
        C++;
    }

    public void draw(Canvas c) {
        p.setARGB(90,200,200,200);
        c.drawRect(x, y, x + w, y + h,p);

        p.setColor(Color.WHITE);
        if(direction == "left"){c.drawText("L", x, y + (h/1.3f),p);}
        if(direction == "right"){c.drawText("R", x, y + (h/1.3f),p);}
        if(direction == "pause"){c.drawText("P", x, y + (h/1.3f),p);}
        if(direction == "fire"){c.drawText("Fire",x + (w/3), y + (h/1.3f),p);}

    }

    public void fire(){
        for(String playerPower: OH.player.power) {
            if (playerPower == "triple") {
                OH.Objects.add(new Bullet((OH.player.x) - (BSizeW + (BSizeW / 2)), OH.player.y, BSizeW, BSizeH, Bdamage, BSpeed, BColor, ObjectID.PlayerBullet, OH));
                OH.Objects.add(new Bullet((OH.player.x + OH.player.w / 2) - (BSizeW / 2), OH.player.y, BSizeW, BSizeH, Bdamage, BSpeed, BColor, ObjectID.PlayerBullet, OH));
                OH.Objects.add(new Bullet((OH.player.x + OH.player.w) + (BSizeW / 2), OH.player.y, BSizeW, BSizeH, Bdamage, BSpeed, BColor, ObjectID.PlayerBullet, OH));
                return;
            }
        }
        OH.Objects.add(new Bullet((OH.player.x + OH.player.w / 2) - (BSizeW / 2), OH.player.y, BSizeW, BSizeH, Bdamage, BSpeed, BColor, ObjectID.PlayerBullet, OH));
    }

}