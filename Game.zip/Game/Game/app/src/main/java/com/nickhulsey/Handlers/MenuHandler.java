package com.nickhulsey.Handlers;

import android.graphics.Canvas;

import com.nickhulsey.Abstracts.Handler;
import com.nickhulsey.MenuObjects.PlayButton;
import com.nickhulsey.game.Game;

/**
 * Created by nickhulsey on 11/30/14.
 */
public class MenuHandler extends Handler{
    public PlayButton PB;

    public MenuHandler(Game game) {
        super(game);
    }

    public void start(){
        if(!init){
            PB = new PlayButton(SCREEN_WIDTH / 4,SCREEN_HEIGHT / 2 - 200,(SCREEN_WIDTH/4) * 2, 200f,this);
        }
    }

    public void tick(){
        game.GH.spaceEmitter.tick();
        PB.tick();

    }

    public void draw(Canvas canvas){
        game.GH.spaceEmitter.draw(canvas);
        PB.draw(canvas);
    }

}
