package com.nickhulsey.Handlers;

import android.graphics.Canvas;

import com.nickhulsey.Abstracts.Handler;
import com.nickhulsey.Gameobjects.Gui.PowerUpDisplay;
import com.nickhulsey.Gameobjects.PowerUps.PowerUpHandler;
import com.nickhulsey.Gameobjects.Gui.Health;
import com.nickhulsey.Gameobjects.Gui.Score;
import com.nickhulsey.Abstracts.Entity;
import com.nickhulsey.Gameobjects.Gui.MoveArrow;
import com.nickhulsey.Gameobjects.Objects.Player;
import com.nickhulsey.Gameobjects.Objects.Spawner;
import com.nickhulsey.Particles.SpaceEmitter;
import com.nickhulsey.game.Game;
import com.nickhulsey.game.ObjectID;

import java.util.ArrayList;

/**
 * Created by nickhulsey on 11/7/14.
 */
public class GameHandler extends Handler{
    //game objects
    public ArrayList<Entity> Objects;
    public Spawner spawner;
    public Player player;

    // pre-made gui
    public Score score;
    public Health health;
    public PowerUpDisplay PowerDisplay;

    public MoveArrow BLeft;
    public MoveArrow BRight;
    public MoveArrow BFire;
    public MoveArrow BPause;

    public SpaceEmitter spaceEmitter;
    public PowerUpHandler powerUpHandler;

    public GameHandler(Game game){
        super(game);
    }

    public void start(){
        if(init == false){
            //init objects
            float bw = 200f;
            float bh = bw;

            player = new Player(SCREEN_WIDTH/2 - 150/2, 1050f, 95f, 95f, ObjectID.Player,this);
            Objects = new ArrayList<Entity>();
            powerUpHandler = new PowerUpHandler(this);

            spawner = new Spawner(this);
            score = new Score(0,80,0,this);
            health = new Health(450,20,80,80,this);
            PowerDisplay = new PowerUpDisplay(SCREEN_WIDTH - 170,250, 150, 150, this);

            BLeft = new MoveArrow(140f, SCREEN_HEIGHT - bh - 430f, bw, bh,"left",ObjectID.Button,this);
            BRight = new MoveArrow(SCREEN_WIDTH - bw - 140, SCREEN_HEIGHT - bh - 430 , bw, bh,"right", ObjectID.Button, this);
            BFire = new MoveArrow(140f,SCREEN_HEIGHT - 375,SCREEN_WIDTH - 280f,230,"fire", ObjectID.Button, this);
            BPause = new MoveArrow(SCREEN_WIDTH - 170,20, 150, 150, "pause", ObjectID.Button, this);

            spaceEmitter = new SpaceEmitter(this);

            init = true;
        }
    }

    public void tick() {
        spawner.tick();
        powerUpHandler.tick();

        //gui
        score.tick();
        health.tick();
        PowerDisplay.tick();

        for (int i = 0; i < Objects.size(); i++) {
            if(i >= 0 && i < Objects.size()) {
                if (Objects.get(i) != null) {
                    Objects.get(i).tick();
                }
            }
        }
        player.tick();

        BLeft.tick();
        BRight.tick();
        BFire.tick();
        BPause.tick();

        spaceEmitter.tick();
    }

    public void draw(Canvas canvas) {
        //draw this first, so you can draw everything else on top of it
        spaceEmitter.draw(canvas);

        player.draw(canvas);

        for (int i = 0; i < Objects.size(); i++) {
            if(i >= 0 && i < Objects.size()) {
                if (Objects.get(i) != null) {
                    Objects.get(i).draw(canvas);
                }
            }
        }

        score.draw(canvas);
        health.draw(canvas);
        PowerDisplay.draw(canvas);

        BFire.draw(canvas);
        BLeft.draw(canvas);
        BRight.draw(canvas);
        BPause.draw(canvas);

    }

}
