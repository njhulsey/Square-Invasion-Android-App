package com.nickhulsey.Gameobjects.Objects.Enemies;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.nickhulsey.Abstracts.Entity;
import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.game.ObjectID;

/**
 * Created by nickhulsey on 11/18/14.
 */
public abstract class Enemy extends Entity {
    protected float speed;
    protected int health;
    protected int worth;
    protected int[] color;

    public Enemy(float x, float y, float w, float h, float difficulty, ObjectID id, GameHandler OH) {
        super(x, y, w, h, id, OH);
        speed =  (1000 + (difficulty * 110) ) / (int)(w * 1.5); //920 //higher number higher speed
        health = (int)(w / (70 - (difficulty * 1.3))); //60 //lower number more lives
        worth = (int)(w / 10);

        color = new int[] {255,0,0,130};

        p.setStyle(Paint.Style.FILL);
        p.setTextSize(70f);
    }

    public abstract void tick();

    public abstract void draw(Canvas c);

    public void die(){
        OH.score.Score += worth;
        OH.Objects.remove(this);
    }

}
