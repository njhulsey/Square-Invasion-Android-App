package com.nickhulsey.Particles;

import android.graphics.Canvas;

import com.nickhulsey.Handlers.GameHandler;

import java.util.Random;

/**
 * Created by nickhulsey on 11/23/14.
 */
public class SpaceEmitter extends ParticleEmitter{

    private Random r;
    private GameHandler GH;

    public SpaceEmitter(GameHandler GH) {
        r = new Random();
        this.GH = GH;
    }

    public void tick() {

        if(count == 7){
            createParticle();
            count = 0;
        }

        for(int i = 0; i < particles.size(); i++){
            if(particles.get(i) != null) {
                synchronized (particles.get(i)) {
                    particles.get(i).tick();
                }
            }
        }
        count++;

    }

    public void draw(Canvas canvas) {

        for(int i = 0; i < particles.size(); i++){
            if(i >= 0 && i < particles.size()) {
                particles.get(i).draw(canvas);
            }
        }
    }

    private void createParticle() {
        int wp = r.nextInt(6) + 1;
        int hp = r.nextInt(10) + 6;
        int xp = r.nextInt((int) GH.SCREEN_WIDTH);
        int yp = 0 - hp;
        int[] color = {255,230,230,230};

        float speed = (hp / wp) * 5;
        float[] vector = {0,speed};
        int life = (int)(GH.SCREEN_HEIGHT / speed);

        particles.add(new Particle((float)xp, (float)yp, (float)wp, (float)hp, color, vector, life, this, GH));


    }



}
