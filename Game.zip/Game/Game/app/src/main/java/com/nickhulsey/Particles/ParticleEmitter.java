package com.nickhulsey.Particles;

import android.graphics.Canvas;

import java.util.ArrayList;

/**
 * Created by nickhulsey on 11/23/14.
 */
public abstract class ParticleEmitter {

    public ArrayList<Particle> particles;
    protected int count;

    public ParticleEmitter(){
        particles  = new ArrayList<Particle>();
    }

    public abstract void tick();
    public abstract void draw(Canvas canvas);

}
