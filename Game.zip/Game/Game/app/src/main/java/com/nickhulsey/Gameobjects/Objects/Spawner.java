package com.nickhulsey.Gameobjects.Objects;


import com.nickhulsey.Gameobjects.Objects.Enemies.BarEnemy;
import com.nickhulsey.Gameobjects.Objects.Enemies.Enemy;
import com.nickhulsey.Gameobjects.Objects.Enemies.FallEnemy;
import com.nickhulsey.Gameobjects.Objects.Enemies.ShootEnemy;
import com.nickhulsey.Gameobjects.Objects.Enemies.WaveEnemy;
import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.game.ObjectID;

import java.util.Random;

/**
 * Created by nickhulsey on 11/18/14.
 */
public class Spawner {
    private GameHandler OH;
    public float difficulty = 1;
    private int SpawnCount, DiffCount = 0;
    private Random r;

    private int EnemySize = 90;

    public Spawner(GameHandler OH){
        this.OH = OH;
        r = new Random();
    }

    public void tick(){
        SpawnCount ++;
        DiffCount ++;

        if(SpawnCount == 56 - difficulty){

            int guess = r.nextInt(4);
            if(guess == 0){createFallEnemy();}
            if(guess == 1){createShootEnemy();}
            if(guess == 2){createBarEnemy();}
            if(guess == 3){createWaveEnemy();}
            SpawnCount = 0;
        }
        if(DiffCount == 490){//500
            //diff max "20"
            if(difficulty < 20){difficulty ++;}
            DiffCount = 0;
        }

    }

    public void createFallEnemy(){
        int w = r.nextInt(EnemySize / 2) + EnemySize;
        int h = w;
        int x = r.nextInt((int)OH.SCREEN_WIDTH - w);

        if(x > 0 && (x + w) + w < OH.SCREEN_WIDTH){
            OH.Objects.add(new FallEnemy((float)x + w,-(float)w,(float)w,(float)h, difficulty, ObjectID.Enemy,OH));
        }else{
            createFallEnemy();
        }

    }

    public void createShootEnemy(){
        int w = r.nextInt(EnemySize / 2) + EnemySize;
        int h = w;
        int x = r.nextInt((int)OH.SCREEN_WIDTH - w);

        if(x > 0 && (x + w) + w < OH.SCREEN_WIDTH){
            OH.Objects.add(new ShootEnemy((float)x + w,-(float)w,(float)w,(float)h, difficulty, ObjectID.Enemy,OH));
        }else{
            createShootEnemy();
        }

    }


    public void createBarEnemy(){
        int check = r.nextInt(3);

        if(check == 1) {
            float gap = r.nextInt(150) + OH.player.w + 100;
            float w1 = r.nextInt((int) (OH.SCREEN_WIDTH - gap));
            float w2 = OH.SCREEN_WIDTH - (w1 + gap);

            OH.Objects.add(new BarEnemy(0, 0 - 50, w1, 50, 12, difficulty, ObjectID.Enemy, OH));
            OH.Objects.add(new BarEnemy(w1 + gap, 0 - 50, w2, 50, 12, difficulty, ObjectID.Enemy, OH));
        }

    }

    public void createWaveEnemy(){
        int w = r.nextInt(EnemySize / 2) + EnemySize;
        int h = w;
        int x = r.nextInt((int)OH.SCREEN_WIDTH - w);

        if(x > 0 && (x + w) + w < OH.SCREEN_WIDTH){
            OH.Objects.add(new WaveEnemy((float)x + w,-(float)w,(float)w,(float)h, difficulty, ObjectID.Enemy,OH));
        }else{
            createWaveEnemy();
        }


    }

}
