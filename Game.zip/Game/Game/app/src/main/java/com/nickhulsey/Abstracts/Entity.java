package com.nickhulsey.Abstracts;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.game.ObjectID;

import java.util.ArrayList;

/**
 * Created by nickhulsey on 11/13/14.
 */
public abstract class Entity {
    public GameHandler OH;
    public ObjectID id;
    public Rect r;
    public int[] color;
    public float x,y,w,h;
    protected Paint p;

    // I could probably move these... but whatever im already paying for not thinking everything out ;-(
    public int damage;
    public ArrayList<String> power;

    protected Entity(float x, float y,float w, float h, ObjectID id, GameHandler OH){
        this.OH = OH;
        this.id = id;
        p = new Paint();
        power = new ArrayList<String>();

        this.w = w;
        this.h = h;

        this.x = x;
        this.y = y;
        r = new Rect((int)x,(int)y,(int)x+(int)w,(int)y+(int)h);
    }
    public abstract void tick();
    public abstract void draw(Canvas canvas);

    public void setRect(){
       r.set((int)x,(int)y,(int)x+(int)w,(int)y+(int)h);
    }

}
