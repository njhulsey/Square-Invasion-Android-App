package com.nickhulsey.Particles;

import android.graphics.Canvas;

import com.nickhulsey.Gameobjects.Objects.Bullet;

import java.util.Random;

/**
 * Created by nickhulsey on 12/11/14.
 */
public class BSparkleEmitter extends ParticleEmitter{
    private Bullet b;
    private int rate,count;
    private Random r;

    public BSparkleEmitter(int rate, Bullet b){
        this.b = b;
        this.rate = rate;
        r = new Random();
        count = 0;
    }

    public void tick() {
        count++;

        if(count == rate){
            count = 0;
            addParticle();
        }

        for(int i = 0; i < particles.size(); i++){
            if(i >= 0 && i < particles.size() - 1 && particles.get(i) != null) {
                if (particles.get(i).vector[1] > 1) {particles.get(i).vector[1] -= 4;}
                if(particles.get(i).color[0] > 25){particles.get(i).color[0] -= 25;}
                particles.get(i).tick();
            }
        }

    }

    public void draw(Canvas canvas) {
        for(int i = 0; i < particles.size(); i++){
            if(i >= 0 && i < particles.size() - 1) {
                if(particles != null){particles.get(i).draw(canvas);}
            }
        }

    }

    private void addParticle(){
        int Pw = 25;
        int Ph = Pw;
        float Px = r.nextInt((int)(b.w + Pw)) + b.x - Pw;
        float Ps = 2;
        float[] vector = {0,Ps};

        particles.add(new Particle(Px, b.y + b.h, Pw, Ph, b.color, vector, 12, this, b.OH));


    }


}
