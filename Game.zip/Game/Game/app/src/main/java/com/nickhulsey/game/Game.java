package com.nickhulsey.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.Handlers.MenuHandler;
import com.nickhulsey.Handlers.OverHandler;
import com.nickhulsey.Handlers.PauseHandler;

import java.io.FileOutputStream;

/**
 * Created by nickhulsey on 11/7/14.
 */
public class Game extends SurfaceView implements Runnable, SurfaceHolder.Callback {
    //TODO: make a abstract button class for and recode buttons
    public final GameHandler GH;
    public final PauseHandler PH;
    public final MenuHandler MH;
    public final OverHandler OH;


    public Vibrator vibrator;

    public float scaleX = 1;
    public float scaleY = 1;

    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;

    public Thread gameT;
    private Render render;

    public String State = "Menu"; //Game, Menu, Pause, Over

    public boolean running = false;
    public boolean pause = false;

    public Game(Context context) {
        super(context);

        SurfaceHolder h = getHolder();
        h.addCallback(this);

        vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        preferences = PreferenceManager.getDefaultSharedPreferences(context);
        editor = preferences.edit();

        MH = new MenuHandler(this);
        GH = new GameHandler(this);
        PH = new PauseHandler(this);
        OH = new OverHandler(this);

        render = new Render(h, context,this);
        gameT = new Thread(this);

    }

    public void run() {
        long lastTime = System.nanoTime();
        double amountOfTicks = 60;
        double ns = 1000000000.0D / amountOfTicks;
        double delta = 0.0D;
        long timer = System.currentTimeMillis();

        while (true) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            while (delta >= 1) {
                delta -= 1;
                tick();
            }
        }
    }

    public void tick(){
        if(pause == false) {
            if (State == "Game") {
                GH.tick();
                if(!GH.Mpressed){GH.Mouse(0,0,0,0);}
            }else if(State == "Pause"){
                PH.tick();
                if(!PH.Mpressed){PH.Mouse(0,0,0,0);}
            }else if(State == "Menu"){
                MH.tick();
                if(!MH.Mpressed){MH.Mouse(0,0,0,0);}
            }else if(State == "Over"){
                OH.tick();
                if(!OH.Mpressed){OH.Mouse(0,0,0,0);}
            }
        }


    }

    public void Draw(Canvas canvas) {
        if(pause == false){
            canvas.drawRGB(10, 10, 10);
            canvas.scale(scaleX,scaleY);

            if(State == "Game"){
                GH.draw(canvas);
            }else if(State == "Pause"){
                PH.draw(canvas);
            }else if(State == "Menu"){
                MH.draw(canvas);
            }else if(State == "Over"){
                OH.draw(canvas);
            }

        }
    }

    public void saveGame(){

        if(GH.score.Score > GH.score.HighScore) {editor.putInt("HScore", GH.score.Score);}
        editor.putInt("LScore",GH.score.Score);

        editor.apply();
    }

    public void loadGame(){
        int HScore = preferences.getInt("HScore",0);
        int LScore = preferences.getInt("LScore",0);

        GH.score.HighScore = HScore;
        GH.score.LastScore = LScore;

    }

    public boolean onTouchEvent(MotionEvent e) {
        PH.Mouse(0,0,0,0); GH.Mouse(0,0,0,0); MH.Mouse(0,0,0,0); OH.Mouse(0,0,0,0);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
            case MotionEvent.ACTION_DOWN:
                GH.Mpressed = true;
                PH.Mpressed = true;
                MH.Mpressed = true;
                OH.Mpressed = true;
                int count = e.getPointerCount();
                for (int i = 0; i < count; i++) {

                    if (i == 0) {
                        float x = e.getX(i) / scaleX;
                        float y = e.getY(i) / scaleY;
                        GH.Mx = x;
                        GH.My = y;

                        PH.Mx = x;
                        PH.My = y;

                        MH.Mx = x;
                        MH.My = y;

                        OH.Mx = x;
                        OH.My = y;

                    } else {
                        float x = e.getX(i) / scaleX;
                        float y = e.getY(i) / scaleY;
                        GH.Mx1 = x;
                        GH.My1 = y;

                        PH.Mx1 = x;
                        PH.My1 = y;

                        MH.Mx1 = x;
                        MH.My1 = y;

                        OH.Mx1 = x;
                        OH.My1 = y;
                    }
                }
                break;
        }

        if (e.getAction() == MotionEvent.ACTION_UP) {
            GH.Mpressed = false;
            PH.Mpressed = false;
            MH.Mpressed = false;
            OH.Mpressed = false;
        }

        return true;
    }

    public void surfaceCreated(SurfaceHolder holder) {
        if(!gameT.isAlive()){
            scaleX = 1080 / getWidth();
            scaleY = 1920 / getHeight();

            if (!GH.init) {
                GH.SCREEN_WIDTH = this.getWidth();
                GH.SCREEN_HEIGHT = this.getHeight();
                GH.start();
            }
            if(!PH.init){
                PH.SCREEN_WIDTH = this.getWidth();
                PH.SCREEN_HEIGHT = this.getHeight();
                PH.start();
            }
            if(!MH.init){
                MH.SCREEN_WIDTH = this.getWidth();
                MH.SCREEN_HEIGHT = this.getHeight();
                MH.start();
            }
            if(!OH.init){
                OH.SCREEN_WIDTH = this.getWidth();
                OH.SCREEN_HEIGHT = this.getHeight();
                OH.start();
            }
            loadGame();
            gameT.start();
        }
        start();
    }
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}
    public void surfaceDestroyed(SurfaceHolder holder) {
        pause = true;
        if(State == "Game"){State = "Pause";}
    }

    public void start() {
        if (!running) {
            render.start();
            running = true;
            pause = false;
        } else {
            render.onResume();
            pause = false;
        }
    }

}