package com.nickhulsey.Gameobjects.Objects;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.nickhulsey.Abstracts.Entity;
import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.Particles.PopUpText;
import com.nickhulsey.game.ObjectID;

import java.util.ArrayList;

public class Player extends Entity {

    public int powerDecay = 350;
    public int powerDecayMax = 350;
    private float speed = 15f;//13

    private float rotatemax = 3;
    private int rotateCount;
    private boolean hit,right,left,back;

    public Player(float x1, float y1, float w, float h, ObjectID id, GameHandler OH) {
        super(x1, y1, w, h, id, OH);
        power.add("nothing");
        color = new int[]{255,130,0,0};

        right = true;
        left = false;
        back = false;

        p.setStyle(Paint.Style.FILL);
        p.setARGB(color[0], color[1], color[2], color[3]);
    }

    public void tick(){
        setRect();

        for(int i = 0; i < OH.Objects.size();i++){
            if(OH.Objects.get(i).id == ObjectID.Enemy || OH.Objects.get(i).id == ObjectID.EnemyBullet){
                if(r.intersect(OH.Objects.get(i).r)){
                    OH.health.lives --;
                    OH.game.vibrator.vibrate(300);
                    hit = true;
                    OH.Objects.remove(i);
                }
            }else if(OH.Objects.get(i).id == ObjectID.PowerUp){
                if(r.intersect(OH.Objects.get(i).r)){
                    OH.Objects.add(new PopUpText(x - (w/2), y - 10, "" + OH.Objects.get(i).power, 90f, 50, OH.Objects.get(i).color, ObjectID.PopupText, OH));
                    if(OH.Objects.get(i).power.get(0) != "health"){addPower(OH.Objects.get(i).power.get(0));}
                    else{OH.health.lives ++;}
                    powerDecay = powerDecayMax;
                    OH.Objects.remove(i);
                    checkPower();
                }
            }
        }

        if(power.get(0) != "nothing"){
            powerDecay--;
            if(powerDecay <= 0) {
                power = new ArrayList<String>();
                power.add("nothing");
                powerDecay = powerDecayMax;
                checkPower();
            }
        }

        rotate();

        //infinite left and right "wrapping"
        if(x < 0 - w){x = OH.SCREEN_WIDTH;}else if(x > OH.SCREEN_WIDTH){x = 0 - w;}
    }

    public void draw(Canvas c) {
        if(hit){c.rotate(rotateCount,OH.SCREEN_WIDTH/2,OH.SCREEN_HEIGHT/2);}
        c.drawRect(x,y,x + w,y + h,p);

    }

    private void rotate(){
        if (OH.health.lives > -1) {
            if (hit) {
                if (right) {
                    rotateCount++;
                    if (rotateCount == rotatemax) {
                        left = true;
                        right = false;
                    }
                }
                if (left) {
                    rotateCount--;
                    if (rotateCount == -rotatemax) {
                        back = true;
                        left = false;
                    }
                }
                if (back) {
                    rotateCount++;
                    if (rotateCount == 0) {
                        right = true;
                        left = false;
                        back = false;
                        hit = false;
                    }
                }
            }
        }
    }

    public void addPower(String powerUp){
        for(int i = 0; i < power.size(); i++){
            if(power.get(i) == "nothing"){power.remove(i);}
        }

        for(int i = 0; i < power.size(); i ++) {if(power.get(i) == powerUp){return;}}

        power.add(powerUp);
    }

    //TODO:triple double fast large health speed(bullet)
    public void checkPower(){
        for(int i = 0; i < power.size(); i++) {
            if (power.get(i) == "nothing") {
                OH.BFire.Bdamage = 1;
                OH.BFire.ROF = 16;
                OH.BFire.BSpeed = 17;

                OH.BFire.BSizeW = 55;
                OH.BFire.BSizeH = 55;

                OH.BFire.BColor = color;

            } else if (power.get(i) == "double") {
                OH.BFire.Bdamage = 2;
                OH.BFire.BColor = new int[]{255, 100, 100, 0};
            } else if (power.get(i) == "rate") {
                OH.BFire.ROF = 7;
            }else if(power.get(i) == "large"){
                OH.BFire.BSizeW = 130;
            }else if(power.get(i) == "triple"){
            }
            else if(power.get(i) == "speed"){
                OH.BFire.BSpeed = 30;
            }
        }

    }

    public void moveRight(){
        x += speed;
    }

    public void moveLeft(){
        x -= speed;
    }

    public void moveUp(){
        y -= speed;
    }

    public void moveDown(){
        y += speed;
    }

}