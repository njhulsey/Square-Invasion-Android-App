package com.nickhulsey.game;

import android.content.pm.ActivityInfo;
import android.os.Bundle;


public class Activity extends android.app.Activity {
    private Game game;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        game = new Game(this);
        setContentView(game);
    }

    public void onPause(){
        game.pause = true;
        super.onPause();
    }

    public void onResume(){
        game.pause = false;
        super.onResume();

    }

}
