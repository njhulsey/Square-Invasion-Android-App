package com.nickhulsey.Abstracts;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Created by nickhulsey on 11/30/14.
 */
public abstract class Button {
    protected Handler H;
    public float x,y,w,h;
    protected Paint p;

    public Button(float x, float y, float w, float h, Handler H){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.H = H;

        p = new Paint();
        p.setStyle(Paint.Style.FILL);
        p.setTextSize(90f);

    }

    public abstract void tick();
    public abstract void draw(Canvas canvas);

}
