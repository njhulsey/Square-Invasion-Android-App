package com.nickhulsey.Particles;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.nickhulsey.Abstracts.Entity;
import com.nickhulsey.Handlers.GameHandler;

/**
 * Created by nickhulsey on 11/23/14.
 */
public class Particle extends Entity{
    public int[] color;
    public float vector[];
    private ParticleEmitter holder;
    private int count,life;

    public Particle(float x, float y, float w, float h, int color[],float[] vector, int life, ParticleEmitter holder, GameHandler OH) {
        super(x, y, w, h, null, OH);
        this.color = new int[]{color[0],color[1], color[2], color[3]};
        this.vector = vector;
        this.holder = holder;
        count = 0;
        this.life = life;
    }

    public void tick() {
        count++;
        if(y > OH.SCREEN_HEIGHT || y < 0 - h || x < 0 - h || x > OH.SCREEN_WIDTH){
            holder.particles.remove(this);
        }
        if(count == life){holder.particles.remove(this);}

        x += vector[0];
        y += vector[1];

    }

    public void draw(Canvas canvas) {
        p.setARGB(color[0],color[1],color[2],color[3]);
        p.setStyle(Paint.Style.FILL);
        canvas.drawRect(x, y, x + w, y + h, p);

    }
}
