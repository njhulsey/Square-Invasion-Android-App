package com.nickhulsey.Gameobjects.Gui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.nickhulsey.Handlers.GameHandler;

/**
 * Created by nickhulsey on 12/4/14.
 */
public class PowerUpDisplay {
    private GameHandler GH;
    private float x,y,w,h;
    private Paint p;
    private int[] color;

    public PowerUpDisplay(float x, float y, float w, float h, GameHandler GH){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.GH = GH;

        p = new Paint();
        p.setStyle(Paint.Style.FILL);

    }


    public void tick(){
        for(int i = 0; i < GH.player.power.size(); i++) {
            String power = GH.player.power.get(i);
            if (power == "nothing") {
                return;
            }
            setColor(power);
        }
    }


    public void draw(Canvas canvas){

        for(int i = 0; i < GH.player.power.size(); i++){
            String power = GH.player.power.get(i);
            if(power == "nothing"){return;}
            setColor(power);
            // draw a rect the size of the power count on the player
            canvas.drawRect(x, y + (i * 210), x + w, y + h + (i * 210), p);
        }

        p.setARGB(150,100,100,150);
        canvas.drawRect(x - 10, y, x - 25, y + (int)(GH.player.powerDecay * 2.3), p);

    }

    private void setColor(String power){
        color = GH.powerUpHandler.getColor(power);
        p.setARGB(color[0],color[1],color[2],color[3]);
    }

}
