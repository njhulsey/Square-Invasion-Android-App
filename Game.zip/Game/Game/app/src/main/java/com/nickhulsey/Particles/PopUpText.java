package com.nickhulsey.Particles;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.nickhulsey.Abstracts.Entity;
import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.game.ObjectID;

/**
 * Created by nickhulsey on 12/6/14.
 */
public class PopUpText extends Entity {
    private String text;
    private float size;
    private int life, count;

    private int fade, alpha;

    public PopUpText(float x, float y, String text, float size, int life, int[] color, ObjectID id, GameHandler OH) {
        super(x, y, 0, 0, id, OH);

        this.color = color;
        this.size = size;
        this.text = text;
        this.life = life;

        p.setStyle(Paint.Style.FILL);
        p.setTextSize(size);

        fade = 255 / life;
    }

    public void tick() {
        count++;
        y -= 1;
        alpha -= fade;
        if(count == life){OH.Objects.remove(this);}

    }

    public void draw(Canvas canvas) {
        p.setARGB(alpha,color[1],color[2],color[3]);
        canvas.drawText(text,x,y,p);
    }
}
