package com.nickhulsey.Gameobjects.Objects.Enemies;

import android.graphics.Canvas;
import android.graphics.Color;

import com.nickhulsey.Gameobjects.Objects.Bullet;
import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.game.ObjectID;

/**
 * Created by nickhulsey on 12/6/14.
 */
public class ShootEnemy extends Enemy{
    private int Rof = 150;
    //fire as soon as your alive
    private int count = Rof;

    private float BSize = 50;

    public ShootEnemy(float x, float y, float w, float h, float difficulty, ObjectID id, GameHandler OH) {
        super(x, y, w, h, difficulty, id, OH);
        color = new int[] {255,0,130,0};
        worth = (int)(w / 10);
    }

    public void tick() {
        setRect();
        //check when to die
        if (y < OH.SCREEN_HEIGHT + h) {
            y += speed;
        } else {
            OH.Objects.remove(this);
        }

        //fire
        count ++;
        if(count >= Rof){
            OH.Objects.add(new Bullet((x + (w / 2)) - (BSize / 2), y + h, BSize, BSize, 1, -(speed + 10), color, ObjectID.EnemyBullet, OH));
            count = 0;
        }

        //check collision with enemy bullet
        for (int i = 0; i < OH.Objects.size(); i++) {
            if (OH.Objects.get(i).id == ObjectID.PlayerBullet) {
                if (r.intersect(OH.Objects.get(i).r) && OH.Objects.get(i) != null) {
                    health -= OH.Objects.get(i).damage;
                    OH.Objects.remove(OH.Objects.get(i));
                }
            }
        }

        if (health <= 0) {die();}

    }
    public void draw(Canvas c) {
        p.setARGB(color[0],color[1],color[2],color[3]);
        c.drawRect(x, y, x + w, y + h, p);

        p.setColor(Color.LTGRAY);
        c.drawText(health+"", x + (w/4), y + (h/1.65f) + 10, p);
    }


}
