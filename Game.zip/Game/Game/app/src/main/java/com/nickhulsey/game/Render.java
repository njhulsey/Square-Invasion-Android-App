package com.nickhulsey.game;

import android.content.Context;
import android.graphics.Canvas;
import android.view.SurfaceHolder;

/**
 * Created by nickhulsey on 11/20/14.
 */
public class Render extends Thread{
    private Object mPauseLock = new Object();
    private boolean mPaused;

    boolean mRun;
    private Canvas mcanvas;
    private SurfaceHolder surfaceHolder;
    private Context context;
    private Game game;


    public Render(SurfaceHolder sholder, Context ctx, Game game){
        surfaceHolder = sholder;
        context = ctx;
        this.game = game;

    }


    public void run(){
        super.run();

        while(true){
            mcanvas = surfaceHolder.lockCanvas();

            if(mcanvas != null){
                game.Draw(mcanvas);
                surfaceHolder.unlockCanvasAndPost(mcanvas);
            }
            synchronized (mPauseLock) {
                while (mPaused) {
                    try {
                        mPauseLock.wait(1);
                    } catch (InterruptedException e) {
                    }
                }
            }
        }

    }
    void setRunning(boolean bRun){mRun = bRun;}

    public void onPause() {
        synchronized (mPauseLock) {
            mPaused = true;
        }
    }

    public void onResume() {
        synchronized (mPauseLock) {
            mPaused = false;
            mPauseLock.notifyAll();
        }
    }

}