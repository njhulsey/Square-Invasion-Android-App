package com.nickhulsey.Gameobjects.PowerUps;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.nickhulsey.Abstracts.Entity;
import com.nickhulsey.Handlers.GameHandler;
import com.nickhulsey.game.ObjectID;

/**
 * Created by nickhulsey on 11/24/14.
 */
public class PowerUp extends Entity{
    private boolean add, subtract;

    public PowerUp(float x, float y, float w, float h, String powerN, int[] color, ObjectID id, GameHandler OH) {
        super(x, y, w, h, id, OH);
        this.power.add(powerN);
        this.color = new int[]{color[0],color[1],color[2],color[3]};

        subtract = true;

        p.setStyle(Paint.Style.FILL);
    }

    public void tick() {
        y += 10;
        if(y > OH.SCREEN_HEIGHT){OH.Objects.remove(this);}
        setRect();

        if(subtract){
            color[0] -= 5;
            if(color[0] < 70){
                subtract = false;
                add = true;
            }
        }else if(add){
            color[0] += 5;
            if(color[0] > 254){
                subtract = true;
                add = false;
            }
        }

    }

    public void draw(Canvas canvas) {
        p.setARGB(color[0], color[1], color[2], color[3]);
        canvas.drawRect(x, y, x + w, y + h, p);

        p.setARGB(color[0] - 50, color[1], color[2], color[3]);
        canvas.drawRect(x - 15, y - 15, x + w + 15, y + h + 15, p);

    }
}
